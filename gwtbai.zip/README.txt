=== KEYMASTER PACKAGE ===

FILES:
├── api.php          → PHP Backend (upload to InfinityFree htdocs/)
├── Login.cpp        → C++ Login Function with your domain configured
├── index.html       → KeyMaster Panel (GitHub Pages frontend)
├── style.css        → Panel styles
└── script.js        → Panel logic

=== SETUP ===

1. PHP SERVER (InfinityFree):
   - Upload api.php to htdocs/
   - URL: http://happy12.gt.tc/api.php
   - Test: http://happy12.gt.tc/api.php?key=TEST&format=json

2. KEYMASTER PANEL (GitHub Pages):
   - Push index.html, style.css, script.js to GitHub repo
   - Enable GitHub Pages
   - In Settings tab -> PHP Server URL: http://happy12.gt.tc/api.php
   - Click "Sync Keys to PHP Server"

3. MOD LOADER:
   - Replace your existing Login() function with Login.cpp
   - URL already set to: http://happy12.gt.tc/api.php?key=%s&format=json
   - Recompile mod

=== C++ DEPENDENCIES ===
- libcurl
- nlohmann/json (JSON for Modern C++)
- JNI (Android)

=== API RESPONSE FORMAT ===
Success: {"status":true,"data":{"token":"XXXX","rng":12345,"modname":"NEXUS MOD MENU","mod_status":"Connected"}}
Failure: {"status":false,"reason":"Invalid signature"}
