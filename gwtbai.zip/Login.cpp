#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <curl/curl.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    auto *mem = (struct MemoryStruct *)userp;
    char *ptr = (char *)realloc(mem->memory, mem->size + realsize + 1);
    if (!ptr) return 0;
    mem->memory = ptr;
    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;
    return realsize;
}

std::string mod_name = "";
std::string mod_status = "";
bool bIsLogin = false;

std::string Login(const char *user_key) {
    if (!g_App || !g_App->activity || !g_App->activity->vm || !g_App->activity->clazz)
        return "Internal Error";

    JNIEnv *env;
    g_App->activity->vm->AttachCurrentThread(&env, 0);
    std::string hwid = std::string(user_key) +
                   Tools::GetAndroidID(env, g_App->activity->clazz) +
                   Tools::GetDeviceModel(env) +
                   Tools::GetDeviceBrand(env);
    std::string UUID = Tools::GetDeviceUniqueIdentifier(env, hwid.c_str());
    g_App->activity->vm->DetachCurrentThread();

    std::string errMsg;
    struct MemoryStruct chunk{};
    chunk.memory = (char *)malloc(1);
    chunk.size = 0;

    CURL *curl = curl_easy_init();
    if (curl) {
        char url[4096];
        sprintf(url, "http://happy12.gt.tc/api.php?key=%s&format=json", user_key);
        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_HTTPGET, 1L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);

        CURLcode res = curl_easy_perform(curl);
        if (res == CURLE_OK) {
            try {
                json result = json::parse(chunk.memory);
                if (result["status"] == true) {
                    std::string token = result["data"]["token"];
                    int rng = result["data"]["rng"];
                    mod_name = result["data"]["modname"];
                    mod_status = result["data"]["mod_status"];
                    bIsLogin = true;
                } else {
                    errMsg = result["reason"].get<std::string>();
                }
            } catch (...) {
                errMsg = "JSON Parse Error";
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }
        curl_easy_cleanup(curl);
    }
    if (chunk.memory) free(chunk.memory);
    return bIsLogin ? "OK" : errMsg;
}
